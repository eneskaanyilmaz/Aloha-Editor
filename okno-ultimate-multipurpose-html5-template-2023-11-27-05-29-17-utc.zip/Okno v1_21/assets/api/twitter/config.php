<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'm1YimUbP6FJx7gE39lhQEg');
    define('CONSUMER_SECRET', 'iqcKv14JbeV6Dp8IckW2DpG5kAjE9g1zTlFVrM');

    // User Access Token
    define('ACCESS_TOKEN', '1357558309-NSTqnsCzxEsRTi6DqpVWlPx4kJATDQpR811ywDb');
    define('ACCESS_SECRET', 'A8T7tkfSAwTRZS7T2tbBWJv5tOMp2V2ecH8Ii8dvwc');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));